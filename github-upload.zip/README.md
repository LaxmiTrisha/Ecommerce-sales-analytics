# 🛒 E-Commerce Sales Analytics

An end-to-end analytics project on e-commerce order data: **MySQL** for exploration and business analysis, **RFM modelling** for customer segmentation, and **Power BI** for the final dashboard.

**Tools:** MySQL 8 (Workbench) · SQL · Power BI Desktop · CSV star-schema (fact + dimension)

---

## 📌 Project at a Glance

| Metric | Value |
|---|---|
| Total orders | **98,666** |
| Product revenue | **13.59 M** |
| Freight value | **2.25 M** |
| Total revenue (Power BI, price + freight) | **15.84 M** |
| Delivery rate | **97.02 %** |
| Cancellation rate | **0.63 %** |

---

## 🗂️ Task Index

| # | Task | Tool | Output |
|---|---|---|---|
| 1 | [Database Setup](#task-1--database-setup) | MySQL | `ecommerce_analytics` database |
| 2 | [Data Exploration](#task-2--data-exploration) | MySQL | Table preview and schema check |
| 3 | [Order Status Analysis](#task-3--order-status-analysis) | MySQL | Orders per status |
| 4 | [Delivery & Cancellation Rate](#task-4--delivery--cancellation-rate) | MySQL | Fulfilment KPIs |
| 5 | [Monthly Order Trend](#task-5--monthly-order-trend) | MySQL | Orders per month |
| 6 | [Overall Business KPIs](#task-6--overall-business-kpis) | MySQL | Orders, revenue, freight |
| 7 | [Top Products by Revenue](#task-7--top-products-by-revenue) | MySQL | Top 10 products |
| 8 | [Product Category Performance](#task-8--product-category-performance) | MySQL | Revenue per category |
| 9 | [Customer Analysis](#task-9--customer-analysis) | MySQL | Repeat buyers and top spenders |
| 10 | [RFM Customer Segmentation](#task-10--rfm-customer-segmentation) | RFM scoring | `dim_customer_rfm.csv` |
| 11 | [Power BI Dashboard](#task-11--power-bi-dashboard) | Power BI | 2-page interactive report |

---

## Task 1 — Database Setup

**Objective:** Create a dedicated database to hold all the e-commerce tables.

```sql
CREATE DATABASE ecommerce_analytics;
USE ecommerce_analytics;
```

![Database setup](images/01_database_setup.png)

---

## Task 2 — Data Exploration

**Objective:** Understand the structure of the data before analysing it.

- Previewed the `orders` table (order ID, customer, status, purchase / approval / delivery timestamps).
- Inspected the `products` table schema: category name, description length, photo count, weight and dimensions.

```sql
SELECT * FROM orders LIMIT 10;
DESCRIBE products;
```

![Orders preview](images/02_orders_preview.png)
![Products schema](images/03_products_schema.png)

---

## Task 3 — Order Status Analysis

**Objective:** See how orders are distributed across their lifecycle statuses.

```sql
SELECT order_status, COUNT(*) AS total_orders
FROM orders
GROUP BY order_status
ORDER BY total_orders DESC;
```

**Result:** `delivered` 96,478 · `shipped` 1,107 · `canceled` 625 · `unavailable` 609 · `invoiced` 314 · `processing` 301 · `created` 5 · `approved` 2

![Order status](images/04_order_status.png)

---

## Task 4 — Delivery & Cancellation Rate

**Objective:** Measure fulfilment performance as percentages.

| Delivered | Canceled | Delivery rate | Cancellation rate |
|---|---|---|---|
| 96,478 | 625 | **97.02 %** | **0.63 %** |

**Insight:** Fulfilment is very reliable, with fewer than 1 in 100 orders cancelled.

![Delivery and cancellation rate](images/05_delivery_cancellation_rate.png)

---

## Task 5 — Monthly Order Trend

**Objective:** Track how order volume changed over time.

```sql
SELECT DATE_FORMAT(order_purchase_timestamp, '%Y-%m') AS order_month,
       COUNT(*) AS total_orders
FROM orders
GROUP BY DATE_FORMAT(order_purchase_timestamp, '%Y-%m')
ORDER BY order_month;
```

**Insight:** Orders grew from 4 in Sep 2016 to 800 in Jan 2017 and over 4,000 per month by Jul–Aug 2017.

![Monthly orders](images/06_monthly_orders.png)

---

## Task 6 — Overall Business KPIs

**Objective:** Get the headline numbers for the whole business.

```sql
SELECT COUNT(DISTINCT order_id)         AS total_orders,
       ROUND(SUM(price), 2)             AS product_revenue,
       ROUND(SUM(freight_value), 2)     AS total_freight
FROM order_items;
```

| Total orders | Product revenue | Total freight |
|---|---|---|
| 98,666 | 13,591,643.70 | 2,251,909.54 |

![Overall KPIs](images/07_overall_kpis.png)

---

## Task 7 — Top Products by Revenue

**Objective:** Identify the individual products that earn the most.

```sql
SELECT product_id,
       COUNT(*) AS total_items_sold,
       ROUND(SUM(price), 2) AS total_revenue
FROM order_items
GROUP BY product_id
ORDER BY total_revenue DESC
LIMIT 10;
```

Then joined with `products` to attach the category name to each product.

**Insight:** The best product sold 195 units for 63,885 revenue. Several of the top 10 are in `beleza_saude` (health & beauty).

![Top products](images/08_top_products.png)
![Top products with category](images/09_top_products_with_category.png)

---

## Task 8 — Product Category Performance

**Objective:** Compare categories by orders, revenue and average item price (`order_items` joined with `products`).

| Category | Orders | Revenue | Avg item price |
|---|---|---|---|
| beleza_saude | 8,836 | 1,258,681 | 130.16 |
| relogios_presentes | 5,624 | 1,205,006 | 201.14 |
| cama_mesa_banho | 9,417 | 1,036,989 | 93.30 |
| esporte_lazer | 7,720 | 988,049 | 114.34 |
| informatica_acessorios | 6,689 | 911,954 | 116.51 |

**Insight:** `beleza_saude` leads on revenue. `cama_mesa_banho` has the most orders but a low average price. `relogios_presentes` has the highest average price, so fewer orders still bring in high revenue.

![Category performance](images/10_category_performance.png)

---

## Task 9 — Customer Analysis

**Objective:** Find repeat customers and the highest-spending customers (`customers` joined with `orders` and `order_items`).

- **Repeat buyers:** customers with more than one order, using `HAVING COUNT(DISTINCT order_id) > 1`. The most loyal customer placed 17 orders.
- **Top spenders:** customers ranked by `SUM(price)`. The top customer spent 13,440.

![Repeat customers](images/11_repeat_customers.png)
![Top spenders](images/12_top_spenders.png)

---

## Task 10 — RFM Customer Segmentation

**Objective:** Group customers by behaviour so the business can target them differently.

- **R**ecency, **F**requency and **M**onetary value are combined into an `RFM_Score` per customer.
- Customers fall into 5 segments: **Champions, Loyal Customers, Promising / Recent, At Risk / Need Attention, Lost Customers**.
- Output is stored in `dim_customer_rfm.csv`, which links to `fact_master_orders.csv` (a star schema: one fact table, one customer dimension).

> ✏️ *Add here: how the R / F / M scores were calculated (script name in `src/`, score ranges or quantiles used).*

---

## Task 11 — Power BI Dashboard

**Objective:** Present the findings visually for business users.

**Data model:** `fact_master_orders` (orders, items, price, freight, category, state) joined to `dim_customer_rfm`.

**DAX measures:** `Total Revenue`, `Total orders`, `AOV`

**Page 1 — Sales Overview**
- Total Revenue card: **15.84 M**
- Total Revenue by product category (column chart)
- Total orders and Average Order Value (AOV ≈ 160)

![Power BI page 1](images/13_powerbi_page1_sales_overview.png)

**Page 2 — Customer Segments (RFM)**
- Donut chart of customers by segment: At Risk 24.3 % · Promising 22.9 % · Loyal 20.1 % · Champions 17.2 % · Lost 15.5 %

![Power BI page 2](images/14_powerbi_page2_rfm_segments.png)

---

## 📁 Repository Structure

```
Ecommerce-sales-analytics/
├── README.md
├── Data/                      # source data
├── src/                       # scripts
├── images/                    # screenshots used in this README
├── fact_master_orders.csv     # fact table
└── dim_customer_rfm.csv       # RFM customer dimension
```

## ▶️ How to Reproduce

1. Load the CSV files into MySQL under the `ecommerce_analytics` database (Task 1).
2. Run the queries in Tasks 2–9.
3. Open Power BI Desktop, import `fact_master_orders.csv` and `dim_customer_rfm.csv`, and rebuild the two report pages (Task 11).
